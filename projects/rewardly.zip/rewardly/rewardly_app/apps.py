from django.apps import AppConfig


class RewardlyAppConfig(AppConfig):
    name = 'rewardly_app'
